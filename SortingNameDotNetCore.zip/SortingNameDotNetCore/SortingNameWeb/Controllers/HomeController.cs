﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using SortingNameBL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SortingNameWeb.Models;

namespace SortingNameWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IFileReader _fileReaderWriter;
        private ISorter _sorter;
        private IndexViewModel _indexmodel;

        public HomeController(ILogger<HomeController> logger, IndexViewModel indexModel, IFileReader fileReaderWriter, ISorter sorter)
        {
            // Get the instances of services and Model which injected in the Request pipeline
            _logger = logger;
            _indexmodel = indexModel;
            _fileReaderWriter = fileReaderWriter;
            _sorter = sorter;
        }

        //Home Page View
        public IActionResult Index()
        {
            if( _indexmodel.SortedNames != null || _indexmodel.Messages != null) // Sorted Names OR Validation Error Messages are there
                return View(_indexmodel);
            else
                return View(new IndexViewModel { Messages = null, SortedNames = null });
        }
      
        [HttpPost]
        public IActionResult UploadNameFileAndSort(List<IFormFile> files)
        {
            _indexmodel.Messages = new List<string>();
            _indexmodel.SortedNames = new List<string>();

            if (files != null && files.Count == 0)
                files = HttpContext.Request.Form.Files.AsEnumerable().ToList();

            if (files == null || files.Count == 0 || files[0] == null || files[0].Length == 0) // Check is the file not uploaded or Empty
            {
                _indexmodel.Messages.Add("Please choose file to Upload and Sort");
                return RedirectToAction("Index");
            }
            else if (!files[0].FileName.Contains(".txt")) // Check is the file not uploaded or Empty
            {
                _indexmodel.Messages.Add("Please upload only text file");
                return RedirectToAction("Index");
            }
            else
            {
                // Get length of file in bytes
                long fileSizeInBytes = files[0].Length;
                // Convert the bytes to KB (1 KB = 1024 Bytes)
                long fileSizeInKB = fileSizeInBytes / 1024;
                // Convert the KB to MB (1 MB = 1024 KB)
                long fileSizeInMB = fileSizeInKB / 1024;

                // Return Message if file size more than 1 MB
                if (fileSizeInMB > 1)
                {
                    _indexmodel.Messages.Add("Please upload less than 1 MB size text file");
                    return RedirectToAction("Index");
                }
                else
                {
                    List<string> unSortedNames = _fileReaderWriter.ReadDataAndWriteToList(files[0]);
                    _indexmodel.SortedNames = _sorter.NamesInAcsending(unSortedNames);

                    return RedirectToAction("Index");
                }
            }
        }

        //This Method for sorting Sample names, which given in the task list
        public IActionResult SortSampleFile()
        {
            _indexmodel.Messages = new List<string>();
            _indexmodel.SortedNames = new List<string>();

            string path = Path.Combine(Directory.GetCurrentDirectory(),"wwwroot", "unsorted-names-list.txt");

            List<string> unSortedNames = _fileReaderWriter.SampleFileDataToList(path);
            _indexmodel.SortedNames = _sorter.NamesInAcsending(unSortedNames);

            return RedirectToAction("Index");
            
        }

        //This Method for clearing Sotred names
        public IActionResult ClearNames()
        {
            //Clear Model Data
            _indexmodel.Messages = new List<string>();
            _indexmodel.SortedNames = new List<string>(); 

            return RedirectToAction("Index");
        }

        //Download Sorted names as Text File
        public IActionResult DownloadFile()
        {
            MemoryStream mr = new MemoryStream();
            TextWriter tw = new StreamWriter(mr);

            foreach (string names in _indexmodel.SortedNames)
            {
                tw.WriteLine(names);
            }

            //Clear Text Writer after write to memory stream
            tw.Flush();

            //Convert to Memory stream to byte array
            byte[] bytes = mr.ToArray();

            //After store it to byte Array, Clear the MemoryStream
            mr.Flush();

            //Downloading as Text file on the Fly
            return File(bytes, "text/plain", "sorted-names-list.txt");
        }
       
        //Error Handling View
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
