﻿using System.Collections.Generic;

namespace SortingNameWeb.Models
{
    public class IndexViewModel
    {
        public List<string> SortedNames { get; set; }

        public List<string> Messages { get; set; }
    }
}
