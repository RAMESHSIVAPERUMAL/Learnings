﻿using System.Collections.Generic;

namespace SortingNameBL
{
    public interface ISorter
    {
        List<string> NamesInAcsending(List<string> textLines);

        List<string> NamesInDescending(List<string> textLines);
    }
}
