﻿using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.IO;

namespace SortingNameBL
{
    public class FileReader : IFileReader
    {
        //Read data from uploaded file, and write each line as string to List
        public List<string> ReadDataAndWriteToList(IFormFile file)
        {
            List<string> result = new List<string>();
            using (var reader = new StreamReader(file.OpenReadStream()))
            {
                while (reader.Peek() >= 0)
                    result.Add(reader.ReadLine());
            }

            return result;

        }

        //Read data from Sample file, and write each line as string to List
        public List<string> SampleFileDataToList(string filePath)
        {
            List<string> result = new List<string>();

            using (var reader = new StreamReader(filePath))
            {
                while (reader.Peek() >= 0)
                    result.Add(reader.ReadLine());
            }

            return result;
        }
    }
}
