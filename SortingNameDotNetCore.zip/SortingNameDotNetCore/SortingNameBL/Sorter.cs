﻿using System.Collections.Generic;
using System.Linq;

namespace SortingNameBL
{
    public class Sorter : ISorter
    {
        //Sorting List of Names in Ascending Order
        public List<string> NamesInAcsending(List<string> textLines)
        {
            var lines = textLines.AsEnumerable().Where(z => z.TrimEnd() != "") // Avoid empty line or string
                            .Select(x => x.TrimEnd().Split(' ').ToArray()) //First Split the each line names in string array, consider space as separater
                            // First preference order by to Last Name, consider last word [even if 2 or 3 or 4 names given], if only one given then give preference to Fisrt Name
                            .OrderBy(x => (x.Length >= 2 && x.Length != 1 ) ? x[x.Length - 1] : x[0]) 
                            .ThenBy(x => x.Length > 0 ? x[0] : "") // Final preference order by to First Name
                            .Select(x => string.Join(" ", x)).ToList(); // Finally join sorted array using Space Separator
            return lines;
        }


        //Sorting List of Names in Descending Order
        public List<string> NamesInDescending(List<string> textLines)
        {
            var lines = textLines.AsEnumerable().Where(z => z.TrimEnd() != "") // Avoid empty line or string
                            .Select(x => x.TrimEnd().Split(' ').ToArray()) //First Split the each line names in string array, consider space as separater
                            // First preference order by to Last Name, consider last word [even if 2 or 3 or 4 names given], if only one given then give preference to Fisrt Name
                            .OrderByDescending(x => (x.Length >= 2 && x.Length != 1) ? x[x.Length - 1] : x[0]) 
                            .ThenByDescending(x => x.Length > 0 ? x[0] : "") // Final preference order by to First Name
                            .Select(x => string.Join(" ", x)).ToList(); // Finally join sorted array using Space Separator
            return lines;
        }
    }
}
