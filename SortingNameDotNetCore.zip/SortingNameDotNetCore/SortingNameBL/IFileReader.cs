﻿using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace SortingNameBL
{
    public interface IFileReader
    {
        List<string> ReadDataAndWriteToList(IFormFile file);

        List<string> SampleFileDataToList(string filePath);
        
    }
}
